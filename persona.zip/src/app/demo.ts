export class Demographics{
client_id: string; 
sex:string;
DOB:string;
age:number;
first:string;
last:string;
phone:string;
email:string;
address_1:string;
city:string;
}