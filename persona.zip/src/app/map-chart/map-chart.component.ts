import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
import HighchartsNetworkgraph from 'highcharts/modules/networkgraph'; 
HighchartsNetworkgraph(Highcharts);
import { ActivatedRoute,Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { PersonaService } from '../persona.service';
import { Options } from "highcharts";

@Component({
  selector: 'app-map-chart',
  templateUrl: './map-chart.component.html',
  styleUrls: ['./map-chart.component.css']
})
export class MapChartComponent  implements OnInit{
 Highcharts: typeof Highcharts = Highcharts;
chartOptions: Options;
client_id="Aug-97";

d(){
this.pservice.categorytop5(this.client_id).subscribe((data:any) => {
      const la=data.map(data => data.CATEGORY);
      console.log(la);
    });

    }
 constructor(private router: Router, private route: ActivatedRoute,private http: HttpClient, private pservice:PersonaService) 
 {
}

  ngOnInit(): void {

  this.d();
  }

 highchart1 = Highcharts;
   chartOption1 = {   
     chart: {
    type: 'pie'
  },
  title: {
        text: 'Categories'
    },
  legend: {
    enabled: true,
    showInLegend: true
  },
  
series:{
  data:[1,2,3]
}





   }

}

